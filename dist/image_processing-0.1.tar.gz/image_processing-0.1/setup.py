from setuptools import setup, find_packages

setup(
    name='image_processing',
    version='0.1',
    packages=find_packages(),
    install_requires=[],
    author='Seu Nome',
    author_email='seuemail@dominio.com',
    description='Cópia do processamento de imagem para projeto',
    url='https://github.com/alanambrozio/image-processing-package',
)