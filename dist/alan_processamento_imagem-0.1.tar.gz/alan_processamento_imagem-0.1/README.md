<<<<<<< HEAD
# alan_processamento_imagem
=======
# alan_processamento_imagem
>>>>>>> 08419edb5f933b6b5aa22c7605e6b178aeee2362

Description. 
The package alan_processamento_imagem is used to:
	Processing
		- Histogram machining
		- Structoral similarity
		- Resize image
	Utils
		- Read image
		- Save image
		- Plot image

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing

```bash
<<<<<<< HEAD
pip install alan_processamento_imagem
=======
pip install alan_processamento_imagem
>>>>>>> 08419edb5f933b6b5aa22c7605e6b178aeee2362
```

## Usage

```python
from alan_processamento_imagem.module1_name import file1_name
file1_name.my_function()
```

## Author
My_name

## License
[MIT](https://choosealicense.com/licenses/mit/)
